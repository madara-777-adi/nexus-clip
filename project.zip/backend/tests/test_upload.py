import io
import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_file_upload_and_delete(client: AsyncClient):
    file_content = b"console.log('Nexus Clip upload test');"
    files = {"file": ("test_script.js", io.BytesIO(file_content), "application/javascript")}

    response = await client.post("/api/v1/upload", files=files)
    assert response.status_code == 201
    data = response.json()
    assert data["success"] is True
    meta = data["data"]
    assert meta["file_name"] == "test_script.js"
    assert "file_url" in meta
