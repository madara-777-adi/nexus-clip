import os
import uuid
from pathlib import Path

from fastapi import UploadFile

from app.core.exceptions import ValidationError

UPLOAD_DIR = Path("/tmp/nexus_uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED_EXTENSIONS = {
    # Images
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg",
    # Documents
    ".pdf", ".txt", ".md", ".csv", ".json", ".doc", ".docx",
    # Audio/Video
    ".mp3", ".wav", ".mp4", ".webm",
    # Archives
    ".zip", ".tar", ".gz",
    # Source code
    ".py", ".js", ".ts", ".html", ".css", ".java", ".cpp", ".rs", ".go",
}


class StorageService:
    """Service handling file storage (Local / Cloudflare R2 object storage abstraction)."""

    async def save_file(self, file: UploadFile) -> dict[str, str | int]:
        """Save uploaded file and return metadata."""
        if not file.filename:
            raise ValidationError("File must have a filename.")

        ext = Path(file.filename).suffix.lower()
        if ext not in ALLOWED_EXTENSIONS:
            # Still accept generic text/data files cleanly
            pass

        file_id = str(uuid.uuid4())
        safe_filename = f"{file_id}_{Path(file.filename).name}"
        destination = UPLOAD_DIR / safe_filename

        content = await file.read()
        file_size = len(content)

        import anyio
        async with await anyio.open_file(destination, "wb") as f:
            await f.write(content)

        # File URL relative or absolute for API
        file_url = f"/static/uploads/{safe_filename}"

        return {
            "file_id": file_id,
            "file_url": file_url,
            "file_name": file.filename,
            "file_size": file_size,
        }

    async def delete_file(self, file_url: str) -> None:
        """Remove file from storage."""
        if not file_url.startswith("/static/uploads/"):
            return
        filename = file_url.replace("/static/uploads/", "")
        file_path = UPLOAD_DIR / filename
        if file_path.exists():
            try:
                os.remove(file_path)
            except OSError:
                pass
